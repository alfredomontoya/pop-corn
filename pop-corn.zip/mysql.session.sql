SELECT * from ventas;
